import os
import cv2
import face_recognition
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)
login_manager = LoginManager(app)

UPLOAD_FOLDER = 'static/faces/'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# User Model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    face_image = db.Column(db.String(100), nullable=True)  # Stores image filename

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def home():
    return render_template('home.html')

# Signup Route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if username exists
        if User.query.filter_by(username=username).first():
            flash("⚠️ Username already exists. Choose a different one.", "danger")
            return redirect(url_for('signup'))

        # Capture face image
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()

        if not ret:
            flash("⚠️ Face not detected. Try again.", "danger")
            return redirect(url_for('signup'))

        image_filename = f"{username}.jpg"
        image_path = os.path.join(UPLOAD_FOLDER, image_filename)
        cv2.imwrite(image_path, frame)

        new_user = User(username=username, password=password, face_image=image_filename)
        db.session.add(new_user)
        db.session.commit()

    
        return redirect(url_for('login'))

    return render_template('signup.html')

# Login with Username & Password
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()

        if user:
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash("❌ Invalid username or password.", "danger")

    return render_template('login.html')

# Face Recognition Login
@app.route('/face_login', methods=['POST'])
def face_login():
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()

    if not ret:
        flash("⚠️ No face detected. Try again.", "danger")
        return redirect(url_for('login'))

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    face_encodings = face_recognition.face_encodings(rgb_frame)

    if not face_encodings:
        flash("❌ No face detected. Try again.", "danger")
        return redirect(url_for('login'))

    # Compare with stored faces
    users = User.query.all()
    for user in users:
        stored_image_path = os.path.join(UPLOAD_FOLDER, user.face_image)
        if os.path.exists(stored_image_path):
            stored_image = face_recognition.load_image_file(stored_image_path)
            stored_encodings = face_recognition.face_encodings(stored_image)

            if stored_encodings and face_recognition.compare_faces([stored_encodings[0]], face_encodings[0])[0]:
                login_user(user)
                return redirect(url_for('index'))

    flash("❌ Face not recognized. Try again.", "danger")
    return redirect(url_for('login'))

# Index Page (Dashboard)
@app.route('/index')
@login_required
def index():
    return render_template('index.html')

# Logout Route
@app.route('/logout')
@login_required
def logout():
    logout_user()
   
    return redirect(url_for('home'))

# Public Admin Panel (Shows all users - No Login Required)
@app.route('/admin')
def admin():
    users = User.query.all()  # Fetch all users from the database
    return render_template('admin.html', users=users)

# Clear All Users (Requires Login)
@app.route('/clear_users', methods=['POST'])
@login_required
def clear_users():
    users = User.query.all()
    for user in users:
        image_path = os.path.join(UPLOAD_FOLDER, user.face_image)
        if os.path.exists(image_path):
            os.remove(image_path)
        db.session.delete(user)

    db.session.commit()
    return redirect(url_for('admin'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Ensures the database is created within the app context
    app.run(debug=True)
